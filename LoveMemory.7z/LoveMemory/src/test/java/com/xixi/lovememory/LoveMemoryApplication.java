package com.xixi.lovememory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoveMemoryApplication {
	public static void main(String[] args) {
		SpringApplication.run(LoveMemoryApplication.class, args);
	}
}
