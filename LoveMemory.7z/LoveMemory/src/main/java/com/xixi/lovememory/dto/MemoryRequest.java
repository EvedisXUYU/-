package com.xixi.lovememory.dto;

import java.util.Date;

public class MemoryRequest {
    private String title;
    private String description;
    private Date memoryDate;
    private String location;

    // getters 和 setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Date getMemoryDate() { return memoryDate; }
    public void setMemoryDate(Date memoryDate) { this.memoryDate = memoryDate; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
}
