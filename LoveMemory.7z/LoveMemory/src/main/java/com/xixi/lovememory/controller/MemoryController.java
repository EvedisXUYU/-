package com.xixi.lovememory.controller;

import com.xixi.lovememory.dto.MemoryRequest;
import com.xixi.lovememory.model.Memory;
import com.xixi.lovememory.service.MemoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/memories")
@CrossOrigin(origins = "http://localhost:3000") // 允许前端源
public class MemoryController {

    @Autowired
    private MemoryService memoryService;

    @GetMapping("/{memoryId}")
    public ResponseEntity<Memory> getMemory(@PathVariable Integer memoryId) {
        Memory memory = memoryService.getMemoryById(memoryId);
        if (memory != null) {
            return ResponseEntity.status(HttpStatus.OK).body(memory);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Memory>> getAllMemories() {
        List<Memory> memories = memoryService.getAllMemories();
        return ResponseEntity.status(HttpStatus.OK).body(memories);
    }

    @PostMapping
    public ResponseEntity<Memory> createMemory(@RequestBody MemoryRequest memoryRequest) {
        Integer memoryId = memoryService.createMemory(memoryRequest);
        Memory memory = memoryService.getMemoryById(memoryId);
        return ResponseEntity.status(HttpStatus.CREATED).body(memory);
    }

    @PutMapping("/{memoryId}")
    public ResponseEntity<Memory> updateMemory(@PathVariable Integer memoryId,
                                               @RequestBody MemoryRequest memoryRequest) {
        Memory memory = memoryService.getMemoryById(memoryId);
        if (memory == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        memoryService.updateMemory(memoryId, memoryRequest);
        Memory updatedMemory = memoryService.getMemoryById(memoryId);
        return ResponseEntity.status(HttpStatus.OK).body(updatedMemory);
    }

    @DeleteMapping("/{memoryId}")
    public ResponseEntity<?> deleteMemory(@PathVariable Integer memoryId) {
        memoryService.deleteMemoryById(memoryId);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
