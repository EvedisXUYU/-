package com.xixi.lovememory.dao;

import com.xixi.lovememory.dto.MemoryRequest;
import com.xixi.lovememory.model.Memory;

import java.util.List;

public interface MemoryDao {
    Memory getMemoryById(Integer memoryId);
    Integer createMemory(MemoryRequest memoryRequest);
    void updateMemory(Integer memoryId, MemoryRequest memoryRequest);
    void deleteMemoryById(Integer memoryId);
    List<Memory> getAllMemories();
}
