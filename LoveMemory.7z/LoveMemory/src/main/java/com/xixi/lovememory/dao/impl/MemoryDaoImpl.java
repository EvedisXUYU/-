package com.xixi.lovememory.dao.impl;

import com.xixi.lovememory.dao.MemoryDao;
import com.xixi.lovememory.dto.MemoryRequest;
import com.xixi.lovememory.model.Memory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class MemoryDaoImpl implements MemoryDao {

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Override
    public Memory getMemoryById(Integer memoryId) {
        String sql = "SELECT memory_id, title, description, memory_date, location, created_date, last_modified_date " +
                "FROM memory WHERE memory_id = :memoryId";
        Map<String, Object> map = new HashMap<>();
        map.put("memoryId", memoryId);
        List<Memory> list = jdbcTemplate.query(sql, map, (rs, rowNum) -> {
            Memory memory = new Memory();
            memory.setMemoryId(rs.getInt("memory_id"));
            memory.setTitle(rs.getString("title"));
            memory.setDescription(rs.getString("description"));
            memory.setMemoryDate(rs.getTimestamp("memory_date"));
            memory.setLocation(rs.getString("location"));
            memory.setCreatedDate(rs.getTimestamp("created_date"));
            memory.setLastModifiedDate(rs.getTimestamp("last_modified_date"));
            return memory;
        });
        return list.isEmpty() ? null : list.get(0);
    }

    @Override
    public Integer createMemory(MemoryRequest memoryRequest) {
        String sql = "INSERT INTO memory (title, description, memory_date, location, created_date, last_modified_date) " +
                "VALUES (:title, :description, :memoryDate, :location, :createdDate, :lastModifiedDate)";
        Map<String, Object> map = new HashMap<>();
        map.put("title", memoryRequest.getTitle());
        map.put("description", memoryRequest.getDescription());
        map.put("memoryDate", memoryRequest.getMemoryDate());
        map.put("location", memoryRequest.getLocation());
        Date now = new Date();
        map.put("createdDate", now);
        map.put("lastModifiedDate", now);

        GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(sql, new MapSqlParameterSource(map), keyHolder);
        return keyHolder.getKey().intValue();
    }

    @Override
    public void updateMemory(Integer memoryId, MemoryRequest memoryRequest) {
        String sql = "UPDATE memory SET title = :title, description = :description, memory_date = :memoryDate, " +
                "location = :location, last_modified_date = :lastModifiedDate WHERE memory_id = :memoryId";
        Map<String, Object> map = new HashMap<>();
        map.put("memoryId", memoryId);
        map.put("title", memoryRequest.getTitle());
        map.put("description", memoryRequest.getDescription());
        map.put("memoryDate", memoryRequest.getMemoryDate());
        map.put("location", memoryRequest.getLocation());
        map.put("lastModifiedDate", new Date());
        jdbcTemplate.update(sql, map);
    }

    @Override
    public void deleteMemoryById(Integer memoryId) {
        String sql = "DELETE FROM memory WHERE memory_id = :memoryId";
        Map<String, Object> map = new HashMap<>();
        map.put("memoryId", memoryId);
        jdbcTemplate.update(sql, map);
    }

    @Override
    public List<Memory> getAllMemories() {
        String sql = "SELECT memory_id, title, description, memory_date, location, created_date, last_modified_date " +
                "FROM memory ORDER BY memory_date DESC";

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Memory memory = new Memory();
            memory.setMemoryId(rs.getInt("memory_id"));
            memory.setTitle(rs.getString("title"));
            memory.setDescription(rs.getString("description"));
            memory.setMemoryDate(rs.getTimestamp("memory_date"));
            memory.setLocation(rs.getString("location"));
            memory.setCreatedDate(rs.getTimestamp("created_date"));
            memory.setLastModifiedDate(rs.getTimestamp("last_modified_date"));
            return memory;
        });
    }
}
