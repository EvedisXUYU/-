package com.xixi.lovememory.service.impl;

import com.xixi.lovememory.dao.MemoryDao;
import com.xixi.lovememory.model.Memory;
import com.xixi.lovememory.service.MemoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MemoryServiceImpl implements MemoryService {

    @Autowired
    private MemoryDao memoryDao;

    @Override
    public com.xixi.lovememory.model.Memory getMemoryById(Integer memoryId) {
        return memoryDao.getMemoryById(memoryId);
    }

    @Override
    public Integer createMemory(com.xixi.lovememory.dto.MemoryRequest memoryRequest) {
        return memoryDao.createMemory(memoryRequest);
    }

    @Override
    public void updateMemory(Integer memoryId, com.xixi.lovememory.dto.MemoryRequest memoryRequest) {
        memoryDao.updateMemory(memoryId, memoryRequest);
    }

    @Override
    public void deleteMemoryById(Integer memoryId) {
        memoryDao.deleteMemoryById(memoryId);
    }

    @Override
    public List<Memory> getAllMemories() {
        return memoryDao.getAllMemories();
    }
}