package com.xixi.lovememory.model;

import java.util.Date;

public class Memory {
    private Integer memoryId;       // 回忆ID
    private String title;           // 标题（如“第一次约会”）
    private String description;     // 描述
    private Date memoryDate;        // 回忆发生的日期
    private String location;        // 地点
    private Date createdDate;       // 创建时间
    private Date lastModifiedDate;  // 最后修改时间

    // getters 和 setters
    public Integer getMemoryId() { return memoryId; }
    public void setMemoryId(Integer memoryId) { this.memoryId = memoryId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Date getMemoryDate() { return memoryDate; }
    public void setMemoryDate(Date memoryDate) { this.memoryDate = memoryDate; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Date getCreatedDate() { return createdDate; }
    public void setCreatedDate(Date createdDate) { this.createdDate = createdDate; }
    public Date getLastModifiedDate() { return lastModifiedDate; }
    public void setLastModifiedDate(Date lastModifiedDate) { this.lastModifiedDate = lastModifiedDate; }
}